package com.example.skulltechmusic.finalhome;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {

    ExpandableListView elv;
    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        elv = (ExpandableListView) findViewById(R.id.expandableListView);
        myAdapter = new MyAdapter(this);
        elv.setAdapter(myAdapter);
        elv.setOnChildClickListener(new ExpandableListView.OnChildClickListener()
        {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                if (groupPosition == 0 && childPosition == 0) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }
                if (groupPosition == 0 && childPosition == 1) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }
                if (groupPosition == 0 && childPosition == 2) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }
                if (groupPosition == 1 && childPosition == 0) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }
                if (groupPosition == 1 && childPosition == 1) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }
                if (groupPosition == 1 && childPosition == 2) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }
                if (groupPosition == 2 && childPosition == 0) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }
                if (groupPosition == 2 && childPosition == 1) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }
                if (groupPosition == 2 && childPosition == 2) {
                    Intent intent;
                    intent = new Intent(Main3Activity.this, Main5ActivityPDF.class);
                    intent.putExtra("key", groupPosition);
                    intent.putExtra("key2", childPosition);
                    startActivity(intent);


                }

                return true;}


        });
    }
}



class MyAdapter extends BaseExpandableListAdapter
{
    Context context;
    String[] year, list;

    public MyAdapter(Context context) {
        this.context = context;
        list = context.getResources().getStringArray(R.array.list);
        year = context.getResources().getStringArray(R.array.Year);
    }

    @Override
    public int getGroupCount() {
        return year.length;
    }

    @Override
    public int getChildrenCount(int i) {
        return list.length;
    }

    @Override
    public Object getGroup(int i) {
        return year[i];
    }

    @Override
    public Object getChild(int i, int i1) {
        return list[i];
    }

    @Override
    public long getGroupId(int i) {
        return year.length;
    }

    @Override
    public long getChildId(int i, int i1) {
        return list.length;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        View row = null;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.list2, parent, false);


        } else {
            row = convertView;
        }
        TextView titleTextView = (TextView) row.findViewById(R.id.textView);


        titleTextView.setText(year[groupPosition]);



        return row;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent)
    {
        View row = null;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.list_item2, parent, false);


        }
        else {
            row = convertView;
        }
        TextView titleTextView = (TextView) row.findViewById(R.id.text);


        titleTextView.setText(list[childPosition]);

        return row;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }
}



