package com.example.skulltechmusic.finalhome;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.net.nsd.NsdManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.borjabravo.readmoretextview.ReadMoreTextView;

public class Main4Activity extends AppCompatActivity {
    private ListView listView;
    private MyAdapter2 myAdapter;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        listView = (ListView) findViewById(R.id.list);
        myAdapter = new MyAdapter2(this);
        listView.setAdapter(myAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    Intent mail, Chooser = null;

                    mail = new Intent(Intent.ACTION_SEND);
                    mail.setData(Uri.parse("mailto:"));
                    String[] to =getResources().getStringArray(R.array.Email);
                    mail.putExtra(Intent.EXTRA_EMAIL, to);
                    mail.setType("message/rfc8822");
                    Chooser = Intent.createChooser(mail, "choose");
                    startActivity(Chooser);


            }
        });
    }


}


class MyAdapter2 extends BaseAdapter
{
    private Context context;
    String[] Name, Qualification, Position, Email;
    int[] images =
            {R.drawable.dsp,R.drawable.viabhavkhirsagar,R.drawable.ameyrevandkar,R.drawable.amitmaurya
                    ,R.drawable.amritamardikar,R.drawable.anandtripathi,R.drawable.ankitatondwalkar,R.drawable.arpitrawankar,R.drawable.asishshekar,R.drawable.atul,R.drawable.beenabalal,R.drawable.dattatraybade,R.drawable.deeptipanjabi,R.drawable.harshadarajale,R.drawable.hemantjadhav,R.drawable.mayurkumaranda,R.drawable.mohit,R.drawable.poojarane,R.drawable.poonambatla,R.drawable.prathameshindulkar,R.drawable.prathameshmestry,R.drawable.pravinpatil,R.drawable.ramarao,R.drawable.ranjanagite,R.drawable.sanjaysingh,R.drawable.santoshjagtap,R.drawable.santendramane,R.drawable.sayalitodkari,R.drawable.sheetalmapare,R.drawable.snehalchothe,R.drawable.swapnilashtekar,R.drawable.tejalpage,R.drawable.vibhawali,R.drawable.vijaypurohit};
    public MyAdapter2(Context context) {
        this.context = context;
        Name = context.getResources().getStringArray(R.array.Name);
        Qualification = context.getResources().getStringArray(R.array.Qualification);
        Position = context.getResources().getStringArray(R.array.Position);
        Email = context.getResources().getStringArray(R.array.Email);
    }

    @Override
    public int getCount() {
        return Name.length;
    }

    @Override
    public Object getItem(int position) {
        return Name[position];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = null;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.list, parent, false);


        } else {
            row = convertView;
        }

        TextView titleTextView = (TextView) row.findViewById(R.id.textView);
        TextView titleTextView2 = (TextView) row.findViewById(R.id.textView2);
        ReadMoreTextView titleTextView3 = (ReadMoreTextView) row.findViewById(R.id.textView3);
        TextView titleTextView4 = (TextView) row.findViewById(R.id.textView4);

        ImageView titleIcon = (ImageView) row.findViewById(R.id.imageView);

        titleTextView.setText(Name[position]);
        titleTextView2.setText(Position[position]);
        titleTextView3.setText(Qualification[position]);
        titleTextView4.setText(Email[position]);
        titleIcon.setImageResource(images[position]);


        return row;

    }
}



