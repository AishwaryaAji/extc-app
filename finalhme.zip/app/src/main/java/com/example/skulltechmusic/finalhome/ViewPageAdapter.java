package com.example.skulltechmusic.finalhome;
import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Admin on 30/06/2017.
 */
public class ViewPageAdapter extends PagerAdapter
{
    private Context context;
    private LayoutInflater layoutinflater;
    private Integer[] images={R.drawable.ameyrevandkar,R.drawable.amitmaurya,R.drawable.amritamardikar,R.drawable.anandtripathi,
            R.drawable.ankitatondwalkar,R.drawable.arpitrawankar,R.drawable.asishshekar,R.drawable.atul,
            R.drawable.beenabalal,R.drawable.dattatraybade,R.drawable.deeptipanjabi,R.drawable.dsp,
            R.drawable.harshadarajale,R.drawable.hemantjadhav,R.drawable.hemantjadhav,R.drawable.mayurkumaranda,
            R.drawable.mohit,R.drawable.poojarane,R.drawable.poonambatla,R.drawable.prathameshindulkar,
            R.drawable.prathameshmestry,R.drawable.pravinpatil,R.drawable.ramarao,R.drawable.ranjanagite,
            R.drawable.sheetalmapare,R.drawable.snehalchothe,R.drawable.swapnilashtekar,R.drawable.tejalpage,
            R.drawable.viabhavkhirsagar,R.drawable.vibhawali,R.drawable.vijaypurohit};

    public ViewPageAdapter(Context context)
    {
        this.context=context;
    }


    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object)
    {
        return (view==(LinearLayout)object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        layoutinflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view=layoutinflater.inflate(R.layout.swipe_layout,container,false);
        ImageView imageView= (ImageView) view.findViewById(R.id.imageView);


        imageView.setImageResource(images[position]);


        ViewPager vp= (ViewPager) container;
        vp.addView(view);
        return view;

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ViewPager vp= (ViewPager) container;

        vp.removeView((LinearLayout) object);
    }
}
