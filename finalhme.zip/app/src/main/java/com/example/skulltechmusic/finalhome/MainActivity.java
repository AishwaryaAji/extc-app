package com.example.skulltechmusic.finalhome;

        import android.content.Intent;
        import android.net.Uri;
        import android.os.Bundle;
        import android.support.v4.view.ViewPager;
        import android.support.v7.app.ActionBar;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.Button;
        import android.widget.ImageButton;
        import android.widget.ImageView;
        import android.widget.Toast;

        import java.util.Timer;
        import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    ViewPager viewpager,viewpager2;
    ImageButton b1,b2,b3,b4,b5,b6;
    Button bt1,bt2,bt3,bt4,bt5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ActionBar actionBar=getSupportActionBar();
        actionBar.hide();
        b1 = (ImageButton) findViewById(R.id.imageg);
        b2 = (ImageButton) findViewById(R.id.imageButton);
        b3 = (ImageButton) findViewById(R.id.imageButton2);
        b4 = (ImageButton) findViewById(R.id.imageButton3);
        b5 = (ImageButton) findViewById(R.id.imageButton4);
        b6 = (ImageButton) findViewById(R.id.bt2);
        bt1 = (Button) findViewById(R.id.extc1);
        bt2 = (Button) findViewById(R.id.extc2);

        bt3 = (Button) findViewById(R.id.extc3);
        bt4 = (Button) findViewById(R.id.for1);
        bt5 = (Button) findViewById(R.id.for2);

        viewpager= (ViewPager) findViewById(R.id.view_pager);
        viewpager2= (ViewPager) findViewById(R.id.view_pager2);
        ViewPageAdapter viewPagerAdapter=new ViewPageAdapter(this);
        ViewpageAdapter2 viewpageAdapter2=new ViewpageAdapter2(this);
        viewpager.setAdapter(viewPagerAdapter);
        viewpager2.setAdapter(viewpageAdapter2);
       Timer timer=new Timer();
        timer.scheduleAtFixedRate(new MyTimerTask(),2000,2000);


    }


    public void proces(View view) {
        if (view.getId() == R.id.imageButton) {
            Intent facebookAppIntent;
            Intent chooser = null;

            facebookAppIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/EXTC-VIT"));

            chooser = Intent.createChooser(facebookAppIntent, "launch_app");
            startActivity(facebookAppIntent);
        } else if (view.getId() == R.id.imageButton2) {
            Intent Instagram;
            Intent chooser = null;
            Instagram = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/extcvit17/"));

            startActivity(Instagram);

        } else if (view.getId() == R.id.imageButton3) {
            Intent chooser = null;
            Intent twitter;
            twitter = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/channel/UCDy6kcOCdlmDYiVheTiBIMg"));
            chooser = Intent.createChooser(twitter, "launch_app");
            startActivity(twitter);

        } else if (view.getId() == R.id.imageButton4) {
            Intent chooser = null;
            Intent youtube;
            youtube = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/extc_vit"));
            chooser = Intent.createChooser(youtube, "launch_app");
            startActivity(youtube);

        } else if (view.getId() == R.id.imageg) {
            Intent chooser = null;
            Intent gmail;
            gmail = new Intent(Intent.ACTION_SEND);
            gmail.setData(Uri.parse("mailto:"));
            String[] to = {"extcvit17@gmail.com"};
            gmail.putExtra(Intent.EXTRA_EMAIL, to);

            gmail.setType("message/rfc822");
            chooser = Intent.createChooser(gmail, "launch_app");
            startActivity(gmail);

        }
        else if (view.getId()==R.id.bt2) {
            Intent chooser= new Intent(MainActivity.this,Main2Activity.class);
            startActivity(chooser);
        }
        else if (view.getId()==R.id.extc1) {
            Intent chooser= new Intent(MainActivity.this,Main3Activity.class);
            startActivity(chooser);
        }
        else if (view.getId()==R.id.extc2) {
            Intent chooser= new Intent(MainActivity.this,Main3Activity.class);
            startActivity(chooser);
        }
        else if (view.getId()==R.id.extc3) {
            Intent chooser= new Intent(MainActivity.this,Main3Activity.class);
            startActivity(chooser);
        }
        else if (view.getId()==R.id.imageView) {
            Intent chooser= new Intent(MainActivity.this,Main4Activity.class);
            startActivity(chooser);
        }
        else if (view.getId()==R.id.for1) {
            Intent chooser= new Intent(MainActivity.this,forum.class);
            startActivity(chooser);
        }

        else if (view.getId()==R.id.for2) {
            Intent chooser= new Intent(MainActivity.this,forum2.class);
            startActivity(chooser);
        }






    }
   public class MyTimerTask extends TimerTask
    {
        @Override
        public void run() {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if(viewpager.getCurrentItem()==0)
                    {
                        viewpager.setCurrentItem(1);
                    }
                    else if(viewpager.getCurrentItem()==1)
                    {
                        viewpager.setCurrentItem(2);
                    }
                    else if(viewpager.getCurrentItem()==2)
                    {
                        viewpager.setCurrentItem(3);
                    }
                    else if(viewpager.getCurrentItem()==3)
                    {
                        viewpager.setCurrentItem(4);
                    }
                    else if(viewpager.getCurrentItem()==4)
                    {
                        viewpager.setCurrentItem(5);
                    }
                    else if(viewpager.getCurrentItem()==5)
                    {
                        viewpager.setCurrentItem(6);
                    }
                    else if(viewpager.getCurrentItem()==6)
                    {
                        viewpager.setCurrentItem(7);
                    }
                    else if(viewpager.getCurrentItem()==7)
                    {
                        viewpager.setCurrentItem(8);
                    }
                    else if(viewpager.getCurrentItem()==8)
                    {
                        viewpager.setCurrentItem(9);
                    }
                    else if(viewpager.getCurrentItem()==9)
                    {
                        viewpager.setCurrentItem(10);
                    }
                    else if(viewpager.getCurrentItem()==10)
                    {
                        viewpager.setCurrentItem(11);
                    }
                    else if(viewpager.getCurrentItem()==11)
                    {
                        viewpager.setCurrentItem(12);
                    }
                    else if(viewpager.getCurrentItem()==12)
                    {
                        viewpager.setCurrentItem(13);
                    }
                    else if(viewpager.getCurrentItem()==13)
                    {
                        viewpager.setCurrentItem(14);
                    }
                    else if(viewpager.getCurrentItem()==14)
                    {
                        viewpager.setCurrentItem(15);
                    }
                    else if(viewpager.getCurrentItem()==15)
                    {
                        viewpager.setCurrentItem(16);
                    }
                    else if(viewpager.getCurrentItem()==16)
                    {
                        viewpager.setCurrentItem(17);
                    }
                    else if(viewpager.getCurrentItem()==17)
                    {
                        viewpager.setCurrentItem(18);
                    }
                    else if(viewpager.getCurrentItem()==18)
                    {
                        viewpager.setCurrentItem(19);
                    }
                    else if(viewpager.getCurrentItem()==19)
                    {
                        viewpager.setCurrentItem(20);
                    }
                    else if(viewpager.getCurrentItem()==20)
                    {
                        viewpager.setCurrentItem(21);
                    }
                    else if(viewpager.getCurrentItem()==21)
                    {
                        viewpager.setCurrentItem(22);
                    }
                    else if(viewpager.getCurrentItem()==22)
                    {
                        viewpager.setCurrentItem(23);
                    }
                    else if(viewpager.getCurrentItem()==23)
                    {
                        viewpager.setCurrentItem(24);
                    }
                    else if(viewpager.getCurrentItem()==24)
                    {
                        viewpager.setCurrentItem(25);
                    }
                    else if(viewpager.getCurrentItem()==25)
                    {
                        viewpager.setCurrentItem(26);
                    }
                    else if(viewpager.getCurrentItem()==26)
                    {
                        viewpager.setCurrentItem(27);
                    }
                    else if(viewpager.getCurrentItem()==27)
                    {
                        viewpager.setCurrentItem(28);
                    }
                    else if(viewpager.getCurrentItem()==28)
                    {
                        viewpager.setCurrentItem(29);
                    }
                    else if(viewpager.getCurrentItem()==29)
                    {
                        viewpager.setCurrentItem(0);
                    }




                }
            });
            MainActivity.this.runOnUiThread(new Runnable()
            {
                @Override
                public void run() {
                    if(viewpager2.getCurrentItem()==0)
                    {
                        viewpager2.setCurrentItem(1);
                    }
                    else if(viewpager2.getCurrentItem()==1)
                    {
                        viewpager2.setCurrentItem(2);
                    }
                    else if(viewpager2.getCurrentItem()==2)
                    {
                        viewpager2.setCurrentItem(3);
                    }
                    else if(viewpager2.getCurrentItem()==3)
                    {
                        viewpager2.setCurrentItem(4);
                    }
                    else if(viewpager2.getCurrentItem()==4)
                    {
                        viewpager2.setCurrentItem(5);
                    }
                    else if(viewpager2.getCurrentItem()==5)
                    {
                        viewpager2.setCurrentItem(6);
                    }
                    else if(viewpager2.getCurrentItem()==6)
                    {
                        viewpager2.setCurrentItem(7);
                    }
                    else if(viewpager2.getCurrentItem()==7)
                    {
                        viewpager2.setCurrentItem(8);
                    }
                    else if(viewpager2.getCurrentItem()==8)
                    {
                        viewpager2.setCurrentItem(9);
                    }
                    else if(viewpager2.getCurrentItem()==9)
                    {
                        viewpager2.setCurrentItem(10);
                    }
                    else if(viewpager2.getCurrentItem()==10)
                    {
                        viewpager2.setCurrentItem(11);
                    }
                    else if(viewpager2.getCurrentItem()==11)
                    {
                        viewpager2.setCurrentItem(12);
                    }
                    else if(viewpager2.getCurrentItem()==12)
                    {
                        viewpager2.setCurrentItem(13);
                    }
                    else if(viewpager2.getCurrentItem()==13)
                    {
                        viewpager2.setCurrentItem(0);
                    }



                }
            });





        }


    }

}
