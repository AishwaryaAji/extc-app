package com.example.skulltechmusic.finalhome;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * Created by Skulltech Music on 06-07-2017.
 */

public class ViewpageAdapter2 extends PagerAdapter {
    private Context context;
    private LayoutInflater layoutinflater;
    private Integer[] images={R.drawable.glass,R.drawable.audi,R.drawable.img6,
            R.drawable.img11,R.drawable.img12,R.drawable.img13,R.drawable.img14,R.drawable.img15,R.drawable.img16,R.drawable.img17,
            R.drawable.img4,
            R.drawable.img5,R.drawable.img10,R.drawable.img8};


    public ViewpageAdapter2(Context context)
    {
        this.context=context;
    }


    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object)
    {
        return (view==(LinearLayout)object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        layoutinflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view=layoutinflater.inflate(R.layout.swipe,container,false);
        ImageView imageView= (ImageView) view.findViewById(R.id.imageView2);
        imageView.setImageResource(images[position]);
        ViewPager vp= (ViewPager) container;
        vp.addView(view);
        return view;

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ViewPager vp= (ViewPager) container;

        vp.removeView((LinearLayout) object);
    }
}
