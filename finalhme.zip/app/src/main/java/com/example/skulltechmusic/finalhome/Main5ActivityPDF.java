package com.example.skulltechmusic.finalhome;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class Main5ActivityPDF extends AppCompatActivity {

    PDFView pdfview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5_pdf);
        ActionBar actionBar=getSupportActionBar();
        actionBar.hide();

        pdfview = (PDFView) findViewById(R.id.pdf);
        Intent myIntent = getIntent();
        int position = myIntent.getIntExtra("key", -1);
        int position2 = myIntent.getIntExtra("key2", -1);


        pdfview.fromAsset("pdf.pdf").load();
    }
}